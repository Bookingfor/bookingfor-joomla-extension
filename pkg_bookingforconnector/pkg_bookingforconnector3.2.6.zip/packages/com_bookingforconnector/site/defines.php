<?php
/**
 * @package   Bookingforconnector
 * @copyright Copyright (c)2006-2016 Ipertrade
 * @license   GNU General Public License version 3, or later
 */
 // No direct access to this file
defined('_JEXEC') or die('Restricted access');

define("BFI_VERSION", "3.2.6");

define("COM_BOOKINGFORCONNECTOR_APIKEY", "aXBlcnRyYWRlOlF5TWQ5V0xPSG53RGhQSzFnVk4vbVE9PQ==");

define("COM_BOOKINGFORCONNECTOR_IMGURL_CDN", "//cdnbookingfor.blob.core.windows.net/");

define("COM_BOOKINGFORCONNECTOR_MERCHANTBEHAVIOUR", false);

define("COM_BOOKINGFORCONNECTOR_USEEXTERNALUPDATEORDER", false);
define("COM_BOOKINGFORCONNECTOR_USEEXTERNALUPDATEORDERSYSTEM", "");

define("COM_BOOKINGFORCONNECTOR_EXTERNALMERCHANTCODE", "ZZZ");

define("COM_BOOKINGFORCONNECTOR_MAXRESOURCESAJAXMERCHANT", 6);

define("COM_BOOKINGFORCONNECTOR_ANONYMOUS_TYPE", "3,4");

define("COM_BOOKINGFORCONNECTOR_KEY", "WZgfdUps");  // chiave di cifratura DEVE essere di 8 caratteri altrimenti genera un errore

