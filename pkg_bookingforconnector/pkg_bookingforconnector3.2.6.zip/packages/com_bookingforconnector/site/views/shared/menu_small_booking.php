<?php
/**
 * @package   Bookingforconnector
 * @copyright Copyright (c)2006-2016 Ipertrade
 * @license   GNU General Public License version 3, or later
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

?>
			<div >
				<ul class="bfi-menu-small bfi-menu-booking">
						<li><a class="bfi-btn bfi-alternative3"><?php echo JTEXT::_('COM_BOOKINGFORCONNECTOR_VIEWS_MENU_BOOKING_MENU1') ?></a></li>
						<li><a class="bfi-btn bfi-alternative3"><?php echo JTEXT::_('COM_BOOKINGFORCONNECTOR_VIEWS_MENU_BOOKING_MENU2') ?></a></li>
						<li><a class="bfi-btn bfi-alternative3"><?php echo JTEXT::_('COM_BOOKINGFORCONNECTOR_VIEWS_MENU_BOOKING_MENU3') ?></a></li>
						<li><a class="bfi-btn bfi-alternative3"><?php echo JTEXT::_('COM_BOOKINGFORCONNECTOR_VIEWS_MENU_BOOKING_MENU4') ?></a></li>
				</ul>
			</div>
