<?php
/**
 * @package   Bookingforconnector
 * @copyright Copyright (c)2006-2016 Ipertrade
 * @license   GNU General Public License version 3, or later
 */



// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// import Joomla view library
jimport('joomla.application.component.view');

/**
 * HTML View class for the HelloWorld Component
 */
class BookingForConnectorViewCondominiumBase extends BFCView
{
	protected $state = null;
	protected $item = null;
	protected $params = null;
	protected $language = null;

	// Overwriting JView display method
	function basedisplay($tpl = NULL, $preparecontent = false) 
	{
		// Initialise variables
		$state		= $this->get('State');
		//$item		= $this->get('Item');

		//$document 	= JFactory::getDocument();
		//$language 	= JFactory::getLanguage()->getTag();

		//$document->addScript('//jquery-ui.googlecode.com/svn/tags/legacy/ui/i18n/ui.datepicker-' . substr($language,0,2) . '.js');
		
		//$document->addStyleSheet('components/com_bookingforconnector/assets/css/resource.css');

		$params = $state->params;

		// se � un pdf non elaboro tutte le richieste
		if($this->getLayout() != 'pdf') {
		
		
			// Check for errors.
			if (count($errors = $this->get('Errors'))) {
				BFCHelper::raiseWarning(500, implode("\n", $errors));
				return false;
			}
			
			if(isset($item->Merchant)){
				BFCHelper::setState($item->Merchant, 'merchant', 'resource');
			}
			/* creating totals */			
		}
		
		$this->assignRef('state', $state);
		$this->assignRef('params', $params);
		//$this->assignRef('item', $item);

	}
	
	function setBreadcrumb($resource, $layout = '', $language) {
		if (!empty($resource)){
				$mainframe = JFactory::getApplication();
				$pathway   = $mainframe->getPathway();
				$items   = $pathway->getPathWay();
				$count = count($items);
				$newPathway = array();
				if($count>1){
					$newPathway = array_pop($items);
				}
				$pathway->setPathway($newPathway);

//				$resourceName = BFCHelper::getLanguage($resource->Name, $language);
				$resourceName = BFCHelper::getLanguage($resource->Name, $this->language, null, array('ln2br'=>'ln2br', 'striptags'=>'striptags')); 

//				$pathway->addItem(
//					$resource->Merchant->Name,
//					JRoute::_('index.php?option=com_bookingforconnector&view=merchantdetails&merchantId=' . $resource->MerchantId . ':' . BFCHelper::getSlug($resource->Merchant->Name))
//				);

				$pathway->addItem(
					$resourceName,
					JRoute::_('index.php?option=com_bookingforconnector&view=condominium&resourceId=' . $resource->CondominiumId . ':' . BFCHelper::getSlug($resourceName))
				);
		}
	}
}
