<?php
/**
 * @package   Bookingforconnector
 * @copyright Copyright (c)2006-2016 Ipertrade
 * @license   GNU General Public License version 3, or later
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$resource = $this->item;
$merchant = $resource->Merchant;

////add counter
//$model      = $this->getModel();
//$retCounter = $model->setCounterByResourceId($resource->ResourceId,"contact",$this->language);

?>
{rsform 5}
