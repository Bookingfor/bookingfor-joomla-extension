<?php
/**
 * @package   Bookingforconnector
 * @copyright Copyright (c)2006-2016 Ipertrade
 * @license    GNU General Public License version 2 or later; see LICENSE
 */
 // No direct access to this file
defined('_JEXEC') or die('Restricted access');

//define("COM_BOOKINGFORCONNECTOR_WSURL", "http://ws.bookingfor.com/BookingService.svc");
define("COM_BOOKINGFORCONNECTOR_APIKEY", "aXBlcnRyYWRlOlF5TWQ5V0xPSG53RGhQSzFnVk4vbVE9PQ==");

//define("COM_BOOKINGFORCONNECTOR_IMGURL", "//ws.bookingfor.com/azure/");
define("COM_BOOKINGFORCONNECTOR_IMGURL_CDN", "//cdnbookingfor.blob.core.windows.net/");

define("COM_BOOKINGFORCONNECTOR_USERATEPLANS", false);
define("COM_BOOKINGFORCONNECTOR_MERCHANTBEHAVIOUR", false);
//define("COM_BOOKINGFORCONNECTOR_USESSL", false);
define("COM_BOOKINGFORCONNECTOR_ENABLEFAVORITES", false);

define("COM_BOOKINGFORCONNECTOR_USEEXTERNALUPDATEORDER", false);
define("COM_BOOKINGFORCONNECTOR_USEEXTERNALUPDATEORDERSYSTEM", "");

define("COM_BOOKINGFORCONNECTOR_EXTERNALMERCHANTCODE", "ZZZ");
define("COM_BOOKINGFORCONNECTOR_CONVERSIONCURRENCY", 1);

define("COM_BOOKINGFORCONNECTOR_MAXRESOURCESAJAXMERCHANT", 6);

define("COM_BOOKINGFORCONNECTOR_GALLERY", "Royalslider");
define("COM_BOOKINGFORCONNECTOR_ANONYMOUS_TYPE", "3,4");

define("COM_BOOKINGFORCONNECTOR_KEY", "WZgfdUps");  // chiave di cifratura DEVE essere di 8 caratteri altrimenti genera un errore

/* NLP */
/*define("COM_BOOKINGFORCONNECTOR_NLP_SYSTEM", "newsletterplus");*/
define("COM_BOOKINGFORCONNECTOR_NLP_SYSTEM", "mailup");

define("COM_BOOKINGFORCONNECTOR_NLP_URL", " http://admin03.newsletterplus.it/frontend/subscribe.aspx");
//define("COM_BOOKINGFORCONNECTOR_NLP_URL", "http://newsletterplus.ipertrade.com/contatti/codice/custom/iscrizioneokko.asp");

define("COM_BOOKINGFORCONNECTOR_NLP_ID", "104");
define("COM_BOOKINGFORCONNECTOR_NLP_CAT_IT", "6123");
define("COM_BOOKINGFORCONNECTOR_NLP_CAT_DE", "6124");
define("COM_BOOKINGFORCONNECTOR_NLP_CAT_EN", "6125");

define("COM_BOOKINGFORCONNECTOR_NLP_OTHERPARAM", "&list=6&group=52");
define("COM_BOOKINGFORCONNECTOR_NLP_OTHERPARAM_IT", "&list=4&group=50");
define("COM_BOOKINGFORCONNECTOR_NLP_OTHERPARAM_DE", "&list=5&group=51");
define("COM_BOOKINGFORCONNECTOR_NLP_OTHERPARAM_EN", "&list=6&group=52");

/*definizione css per bootstrap 3 o 2 
bootstrap 3:
define("COM_BOOKINGFORCONNECTOR_BOOTSTRAP_ROW", "row");
define("COM_BOOKINGFORCONNECTOR_BOOTSTRAP_COL", "col-md-");
bootstrap 2:
define("COM_BOOKINGFORCONNECTOR_BOOTSTRAP_ROW", "row-fluid");
define("COM_BOOKINGFORCONNECTOR_BOOTSTRAP_COL", "span");

define("COM_BOOKINGFORCONNECTOR_BOOTSTRAP_ROW", "row");
define("COM_BOOKINGFORCONNECTOR_BOOTSTRAP_COL", "col-md-");
*/
